class Persona
{
  constructor(nombre)
  {
    this.nombre=nombre;
  }
}
